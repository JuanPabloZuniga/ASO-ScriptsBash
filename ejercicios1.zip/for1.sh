for i in 1 2 3
do
	echo "El valor de \$i es $i"
done
