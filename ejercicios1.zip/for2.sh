for planeta in Mercurio Venus Tierra Marte Júpiter Saturno Urano Neptuno Plutón
do
	echo $planeta # cada planaeta en una linea independiente
done

echo; echo

for planeta in " Mercurio Venus Tierra Marte Júpiter Saturno Urano Neptuno Plutón"
do
        echo $planeta # cada planaeta en ls msima linea
done
