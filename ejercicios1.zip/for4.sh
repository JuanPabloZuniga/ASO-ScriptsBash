numeros="9 7 3 8 37.53"
for num in  `echo $numeros`
do
	echo  "$num"
	#echo -n "$num" -n no añade intro
done;
echo
