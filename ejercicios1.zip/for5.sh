for planeta in "Mercurio 36" "Venus 67" "Tierra  93" "Marte 142" "Jupiter 483"
do 
	set  $planeta
	# $1 para el primer parametro y $2 para el segundo
	echo "$1\t\t$2,000,000 millas del sol"
done
