for a #si no se especofica lissta, hay que pasar argumentos al fichero
do
	echo -n "$a"
done
